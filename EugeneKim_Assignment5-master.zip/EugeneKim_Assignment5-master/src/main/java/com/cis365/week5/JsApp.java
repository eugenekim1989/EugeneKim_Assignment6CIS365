package com.cis365.week5;

import org.springframework.stereotype.Controller;

@Controller
public class JsApp {
}
